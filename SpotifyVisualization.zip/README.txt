Usage Instructions

In bilevelPartition.js, you can change the first 3 variables: inputFile, genreList, and colorList.

inputFile: the JSON file containing all the music data
genreList and colorList: each genre maps to a color, so make sure the number of genres = number of colors!

Open spotifyVisualization.html inside a web server like XAMPP.